AEROFLEX MULTI-PAGE MANUFACTURING WEBSITE
========================================

Pages:
- index.html — Home
- about.html — About Us
- products.html — Product categories
- manufacturing.html — Manufacturing process
- customization.html — OEM / ODM and private label options
- contact.html — Enquiry form demo

How to preview:
1. Extract the ZIP.
2. Open index.html in a browser.

Before publishing:
- Replace sample/placeholder claims with verified company details.
- Add real contact details and product photography.
- The contact form is front-end demo only; connect it to an email/form backend before going live.
- Add hosting/domain and test on mobile devices.
