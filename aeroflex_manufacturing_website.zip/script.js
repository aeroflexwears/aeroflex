
const toggle=document.querySelector('.menu-toggle');
const nav=document.querySelector('.navlinks');
if(toggle&&nav){toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));toggle.textContent=open?'✕':'☰';});}
const year=document.getElementById('year');if(year)year.textContent=new Date().getFullYear();
const form=document.getElementById('quote-form');
if(form){form.addEventListener('submit',e=>{e.preventDefault();const d=new FormData(form);const message=`AeroFlex project enquiry\nName: ${d.get('name')}\nBrand: ${d.get('company')||'Not provided'}\nEmail: ${d.get('email')}\nPhone: ${d.get('phone')||'Not provided'}\nProduct: ${d.get('product')}\nQuantity: ${d.get('quantity')||'Not decided'}\nDetails: ${d.get('message')}`;const notice=document.getElementById('form-notice');notice.textContent='Enquiry draft prepared below. Copy it and send it to your business contact. This demo does not transmit data.';let out=document.getElementById('draft-output');if(!out){out=document.createElement('textarea');out.id='draft-output';out.readOnly=true;out.style.cssText='grid-column:1/-1;min-height:190px';form.appendChild(out);}out.value=message;out.focus();out.select();});}
