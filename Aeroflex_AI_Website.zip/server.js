require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.GEMINI_API_KEY;

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/status", (_req, res) => {
  res.json({ ready: Boolean(API_KEY && API_KEY !== "PASTE_YOUR_GEMINI_API_KEY_HERE") });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!API_KEY || API_KEY === "PASTE_YOUR_GEMINI_API_KEY_HERE") {
      return res.status(503).json({
        error: "Gemini API key set nahi hai. Project folder mein .env file bana kar GEMINI_API_KEY add karein."
      });
    }

    const message = String(req.body?.message || "").trim();
    const history = Array.isArray(req.body?.history) ? req.body.history.slice(-10) : [];
    if (!message) return res.status(400).json({ error: "Pehle apna message likhein." });
    if (message.length > 8000) return res.status(413).json({ error: "Message bohat lamba hai. 8,000 characters se kam rakhein." });

    const contents = [];
    for (const item of history) {
      if (!item || !["user", "model"].includes(item.role) || typeof item.text !== "string") continue;
      contents.push({ role: item.role, parts: [{ text: item.text.slice(0, 8000) }] });
    }
    contents.push({ role: "user", parts: [{ text: message }] });

    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + encodeURIComponent(API_KEY),
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: "You are Aero AI, a helpful, clear, friendly AI assistant. Reply in the same language as the user. Be accurate and concise. If you are uncertain, say so." }]
          },
          contents,
          generationConfig: { temperature: 0.7, maxOutputTokens: 1200 }
        })
      }
    );

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const msg = data?.error?.message || "Gemini API request failed.";
      return res.status(response.status === 429 ? 429 : 502).json({ error: msg });
    }
    const answer = (data?.candidates?.[0]?.content?.parts || [])
      .map(p => p.text || "")
      .join("\n")
      .trim();
    if (!answer) return res.status(502).json({ error: "AI ne empty response diya. Dobara try karein." });
    res.json({ answer });
  } catch (err) {
    console.error("Chat endpoint error:", err.message);
    res.status(500).json({ error: "Server se response nahi mila. Internet aur server check karein." });
  }
});

app.listen(PORT, () => {
  console.log(`Aeroflex AI Studio running at http://localhost:${PORT}`);
});
